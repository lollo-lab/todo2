#ifndef __REG__UTIL__H__
#define __REG__UTIL__H__

BOOL CopyRegistryKey(HKEY hkRootFrom, const CString& strFromPath, HKEY hkRootTo, const CString& strToPath);

#endif //__REG__UTIL__H__