﻿// -- FILE ------------------------------------------------------------------
// name       : RtfFontCollection.cs
// project    : RTF Framelet
// created    : Leon Poyyayil - 2008.05.20
// language   : c#
// environment: .NET 2.0
// copyright  : (c) 2004-2009 by Itenso GmbH, Switzerland
// --------------------------------------------------------------------------
using System;
using System.Collections;

namespace Itenso.Rtf.Model
{

	// ------------------------------------------------------------------------
	public sealed class RtfFontCollection : ReadOnlyBaseCollection, IRtfFontCollection
	{

		// ----------------------------------------------------------------------
		public RtfFontCollection()
		{
		} // RtfFontCollection

		// ----------------------------------------------------------------------
		public bool ContainsFontWithId( string fontId )
		{
			return this.fontByIdMap.ContainsKey( fontId );
		} // ContainsFontWithId

		// ----------------------------------------------------------------------
		public IRtfFont this[ int index ]
		{
			get { return InnerList[ index ] as IRtfFont; }
		} // this[ int ]

		// ----------------------------------------------------------------------
		public IRtfFont this[ string id ]
		{
			get { return this.fontByIdMap[ id ] as IRtfFont; }
		} // this[ string ]

		// ----------------------------------------------------------------------
		public void CopyTo( IRtfFont[] array, int index )
		{
			InnerList.CopyTo( array, index );
		} // CopyTo

		// ----------------------------------------------------------------------
		public void Add( IRtfFont item )
		{
			if ( item == null )
			{
				throw new ArgumentNullException( "item" );
			}
			InnerList.Add( item );
			this.fontByIdMap.Add( item.Id, item );
		} // Add

		// ----------------------------------------------------------------------
		public void Clear()
		{
			InnerList.Clear();
			this.fontByIdMap.Clear();
		} // Clear

		// ----------------------------------------------------------------------
		// members
		private readonly Hashtable fontByIdMap = new Hashtable();

	} // class RtfFontCollection

} // namespace Itenso.Rtf.Model
// -- EOF -------------------------------------------------------------------
