var annotated =
[
    [ "Chronicle", "namespace_chronicle.html", "namespace_chronicle" ]
];