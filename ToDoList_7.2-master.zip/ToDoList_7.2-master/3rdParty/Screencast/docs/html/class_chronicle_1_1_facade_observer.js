var class_chronicle_1_1_facade_observer =
[
    [ "capturePaused", "class_chronicle_1_1_facade_observer.html#a325f18ad70ba77f7236e7deb1af3ef59", null ],
    [ "captureResumed", "class_chronicle_1_1_facade_observer.html#af0ec50bc87e0f584e827fb006363a956", null ],
    [ "captureStarted", "class_chronicle_1_1_facade_observer.html#abd4e3584a338615381aa257f91007ad2", null ],
    [ "captureStopped", "class_chronicle_1_1_facade_observer.html#a729a4c513bc9622e7c62fc004be8540b", null ]
];