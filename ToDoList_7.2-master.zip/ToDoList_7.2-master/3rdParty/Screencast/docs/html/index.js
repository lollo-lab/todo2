var index =
[
    [ "Introduction", "intro_page.html", null ],
    [ "Revision History", "revisions_page.html", null ],
    [ "Overview", "overview_page.html", null ],
    [ "Initialization and Cleanup", "init_page.html", null ],
    [ "Recording Waypoints", "waypoints_page.html", [
      [ "Registration", "waypoints_page.html#register_sec", null ],
      [ "Tools", "waypoints_page.html#tools_sec", null ],
      [ "Timestamps and Duration", "waypoints_page.html#times_sec", null ],
      [ "Files", "waypoints_page.html#files_sec", null ],
      [ "Dialogs", "waypoints_page.html#dialogs_sec", null ],
      [ "Settings", "waypoints_page.html#settings_sec", null ]
    ] ],
    [ "Controlling and Querying the Capture State", "capture_page.html", null ],
    [ "Monitoring the Capture State", "monitoring_page.html", null ],
    [ "Controlling the Chronicle Desktop Utility", "utility_page.html", null ]
];