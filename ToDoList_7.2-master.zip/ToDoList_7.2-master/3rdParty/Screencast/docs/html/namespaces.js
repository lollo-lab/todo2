var namespaces =
[
    [ "Chronicle", "namespace_chronicle.html", null ]
];