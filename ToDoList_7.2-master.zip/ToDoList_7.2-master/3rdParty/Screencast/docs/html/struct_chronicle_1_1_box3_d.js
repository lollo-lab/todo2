var struct_chronicle_1_1_box3_d =
[
    [ "Box3D", "struct_chronicle_1_1_box3_d.html#a183b83e683f3ee99055bfee0d09f3ea7", null ],
    [ "Box3D", "struct_chronicle_1_1_box3_d.html#a85dfe190d587f786297b317a095e6570", null ],
    [ "center", "struct_chronicle_1_1_box3_d.html#a675401dfd0fc0ea5adcaf0c9983b4698", null ],
    [ "extent", "struct_chronicle_1_1_box3_d.html#a2ae3c722ac2482e6b2f7bb36907907a0", null ]
];