var struct_chronicle_1_1_color =
[
    [ "Color", "struct_chronicle_1_1_color.html#a2fd74d593ba921ecc38b2a9573a91938", null ],
    [ "Color", "struct_chronicle_1_1_color.html#a87d603507c12b4889ac222e7c44ecb22", null ],
    [ "a", "struct_chronicle_1_1_color.html#a06689afcc84fa330339ad35714ddca49", null ],
    [ "b", "struct_chronicle_1_1_color.html#a017bf7b0162846731dcd4776fefa614d", null ],
    [ "g", "struct_chronicle_1_1_color.html#abca9c3722488dab9e04e384e8edbce41", null ],
    [ "r", "struct_chronicle_1_1_color.html#a4ef15a7e2cdfa2f6de244991a01ffb01", null ]
];