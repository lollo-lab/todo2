var struct_chronicle_1_1_point =
[
    [ "Point", "struct_chronicle_1_1_point.html#a1fcce85169528516a9d00cf3d538bc89", null ],
    [ "Point", "struct_chronicle_1_1_point.html#a376365ddfdaaa893882417e46a390523", null ],
    [ "x", "struct_chronicle_1_1_point.html#a6e13bb3c84a835c87500b5ada434c90e", null ],
    [ "y", "struct_chronicle_1_1_point.html#ac128200d41e144ae37cc3b05ea25d6c2", null ]
];