var struct_chronicle_1_1_point_f =
[
    [ "PointF", "struct_chronicle_1_1_point_f.html#ac67b87ec61abde8cbbb3e88c898fb18d", null ],
    [ "PointF", "struct_chronicle_1_1_point_f.html#a9b6f0852d70b6c1d6f5bcc2b633c6faf", null ],
    [ "x", "struct_chronicle_1_1_point_f.html#a2e30fb1fcdc93afc92440dbeead861f3", null ],
    [ "y", "struct_chronicle_1_1_point_f.html#ac0796b3895f67483c73202b05cb97b3e", null ]
];