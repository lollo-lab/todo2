var struct_chronicle_1_1_vector2_d =
[
    [ "Vector2D", "struct_chronicle_1_1_vector2_d.html#a43f70e217008e03aeff2a352b2ca9524", null ],
    [ "Vector2D", "struct_chronicle_1_1_vector2_d.html#a1cffb5b29dae077bade3ca75a84222cf", null ],
    [ "x", "struct_chronicle_1_1_vector2_d.html#ada9850772044fbfc4ea4726d44997ed2", null ],
    [ "y", "struct_chronicle_1_1_vector2_d.html#a74309d4f6649f887cc7abe2b4f261a43", null ]
];